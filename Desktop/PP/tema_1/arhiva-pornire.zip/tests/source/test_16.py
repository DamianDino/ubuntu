def main():
	a = 3
	b = 10

	c = a - b
	b = c - a
