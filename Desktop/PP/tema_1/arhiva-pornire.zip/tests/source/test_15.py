def main(a, b):
	d = b
	a = 3
	b = 2
	c = a + b
	d = c - a
	e = d % 2
	return c + a
