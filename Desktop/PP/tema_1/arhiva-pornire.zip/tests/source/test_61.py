def main():
	a = 9
	b = 3
	c = 4
	d = 5
	x = prod(a, b, c, d)
	y = prod(x, 2, 3, 4, 5, 6)
	z = x + y
