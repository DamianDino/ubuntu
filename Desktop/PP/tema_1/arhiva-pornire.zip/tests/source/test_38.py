def main():
	i = 10
	j = 0
	c = 0

	while i != j:
		i -= 1
		j += 1
		c += 2 

	i = 0
	j = 10
	while i < j:
		i += 1
		j -= 1
		c += 2
 