def main():
	a = 2
	b = 3

	c = a + b
	d = c + a
	e = c + b
	f = d + a
	g = f + a
	h = g + b
