def main():
	for x in [1, 2, 3]:
		print(x)

	i = 0
	while i < 10:
		print(i)
		i += 1
