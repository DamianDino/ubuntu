def main():
	a = 9
	b = 16
	x = sqrt(a)
	y = sqrt(b)
	s = x + y
	c = 9 + 6
	c = c + 10
	z = sqrt(c)
	s += z
