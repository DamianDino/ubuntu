def main(a):
	b = a
	a = 3
	c = 2
