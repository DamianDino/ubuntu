def main():
	a = 3
	b = 10

	c = a % b
	c = 15
	b = c % a
