def main():
	a = 3
	i = 0

	while i < 5:
		a = a + 2
		i = i + 1

	i = 0
	b = 1
	while i != 10:
		i = i + 1
		b = b + i
