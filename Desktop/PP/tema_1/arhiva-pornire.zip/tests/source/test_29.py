def main():
	a = 5
	b = 7

	if a > b:
		b = a

	if a < b:
		c = a + b

	if b > a:
		d = a - b

	if c == d:
		e = c - d

	if c != d:
		e = c + d
