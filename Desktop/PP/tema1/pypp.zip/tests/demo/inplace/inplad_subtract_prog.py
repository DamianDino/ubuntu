def main():
    a = 5

    a -= 3
    a -= 2
