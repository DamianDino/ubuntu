def main():
    a = 3
    b = 5

    if a > 5:
        b = 3
        a = 10
