def main():
    a = 3
    b = 5

    if a >= 4:
        b = 4
        a = 10
