def main():
    a = 3
    b = 5

    if a < 2:
        b = 3
        a = 10
