def main():
    a = 3
    b = 5

    if a < 10:
        b = 3
        a = 10
