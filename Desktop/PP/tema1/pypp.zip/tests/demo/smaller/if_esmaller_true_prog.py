def main():
    a = 3
    b = 5

    if a <= 3:
        b = 7
        a = 10
