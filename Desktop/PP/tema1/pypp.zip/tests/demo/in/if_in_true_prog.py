def main():
    a = 3
    b = 5

    if a in [1,3,5]:
        b = 3
        a = 10
