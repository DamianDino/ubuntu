def main():
    a = 3
    b = 5

    if a in [1,2,5,6]:
        b = 3
        a = 10
