def main():
    a = 3
    b = 5
    c = b
