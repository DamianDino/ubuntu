def main():
    a = 5
    b = 10

    c = add(a, b)
