def main():
    a = 4

    c = sqrt(a)
