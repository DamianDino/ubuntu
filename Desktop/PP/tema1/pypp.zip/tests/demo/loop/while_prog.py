def main():
    a = 3
    i = 0

    while i < 5:
        a = a + 2
        i = i + 1
