def main():
    a = 5
    b = 4

    if a != b:
        a += 1
        b -= 1

    if b != 3:
        b = a
        a = b
