import java.io.IOException;
import java.util.*;
import java.io.File;
import java.util.Collections;
import java.io.PrintWriter;

public class P1 {

    public static final String INPUT_FILE = "p1.in";
    public static final String OUTPUT_FILE = "p1.out";

    static class Task {
        int N;
        ArrayList<Integer> list = new ArrayList<Integer>();
        int result;

        private void readInput(){
            try{
                Scanner scanner = new Scanner(new File(INPUT_FILE));
                N = scanner.nextInt();
                for(int i=0; i<N; i++){
                    int aux = scanner.nextInt();
                    list.add(aux);
                }
                scanner.close();
            } catch (IOException e){
                throw new RuntimeException(e);
            }
        }

        private void writeOutput(int result){
            try{
                PrintWriter pw = new PrintWriter(new File(OUTPUT_FILE));
                pw.println(result);
                pw.close();
            } catch (IOException e){
                throw new RuntimeException(e);
            }
        }

        private int getResult(){
            int tuzgu = 0;
            int ritza = 0;
            Collections.sort(list, Collections.reverseOrder());
            for(int i=0; i<list.size(); i++){
                if (i%2 == 0){
                    tuzgu += list.get(i);
                } else{
                    ritza += list.get(i);
                }
            }
            return tuzgu - ritza;
        }

        public void solve(){
            readInput();
            writeOutput(getResult());
        }
    }

    public static void main (String[] args){
        Task task = new Task();
        task.solve();
    }
}