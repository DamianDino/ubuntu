import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class P3 {

    public static final String INPUT_FILE = "p3.in";
    public static final String OUTPUT_FILE = "p3.out";

    static class Task {
        int N;
        int arr[];
        int result;

        private void readInput(){
            try{
                File file = new File("p3.in");
                Scanner scanner = new Scanner(new File("p3.in"));
                N = scanner.nextInt();
                arr = new int[N];
                for(int i=0; i<N; i++){
                    arr[i] = scanner.nextInt();
                }
                scanner.close();
            } catch (IOException e){
                e.printStackTrace();
            }
        }

        private void writeOutput(long result){
            try{
                PrintWriter pw = new PrintWriter(new File("p3.out"));
                pw.println(result);
                pw.close();
            } catch (IOException e){
                throw new RuntimeException(e);
            }
        }

        private long getResult(){

            /* dp[i][j] = maximum amount you can get if you move first */
            long[][] dp = new long[N][N];

            /* base case: if we have only one number (N=1), we will pick that number */
            for(int j=0; j<N ;j++) {
                /* the main diagonal is filled with the value of each number in the array arr */
                dp[j][j]=arr[j];
            }

            /* 2 numbers case: if we have two numbers, we will pick the bigger one */
            for(int j=0; j<N-1; j++) {
                /* the second diagonal is filled with the max between its west and south neighbours */
                dp[j][j+1]=Math.max(arr[j],arr[j+1]);
            }

            /* the general case, compute dp[j][j+i] */
            for(int i=2; i<N; i++) {
                for(int j=0; i+j <N; j++) {

                    long x=arr[j]+Math.min(dp[j+1][j+i-1], dp[j+2][j+i]);

                    long y=arr[j+i]+Math.min(dp[j][j+i-2], dp[j+1][j+i-1]);

                    dp[j][j+i]=Math.max(x,y);
                }
            }

            long sum = 0;
            for(int s=0; s<N; s++){
                sum += arr[s];
            }

            long a  = sum - dp[0][N-1];

            return (dp[0][N - 1]) - a;

        }

        public void solve(){
            readInput();
            writeOutput(getResult());
        }
    }

    public static void main (String[] args){
        new Task().solve();
    }
}