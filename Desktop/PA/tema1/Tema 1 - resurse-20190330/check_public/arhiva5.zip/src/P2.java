import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.Collections;
import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

import static java.util.Arrays.*;

public class P2 {

    public static final String INPUT_FILE = "p2.in";
    public static final String OUTPUT_FILE = "p2.out";

    static class Task {
        int N, k;
        Integer arr[];
        int result;

        private void readInput(){
            try{
                Scanner scanner = new Scanner(new File("p2.in"));
                N = scanner.nextInt();
                k = scanner.nextInt();
                arr = new Integer[N];
                for(int i=0; i<N; i++){
                    arr[i] = scanner.nextInt();
                    //System.out.println(arr[i]);
                }

                //System.out.println(arr.toString());
                scanner.close();
            } catch (IOException e){
                e.printStackTrace();
            }
        }

        private void writeOutput(int result){
            try{
                PrintWriter pw = new PrintWriter(new File("p2.out"));
                pw.println(result);
                pw.close();
            } catch (IOException e){
                throw new RuntimeException(e);
            }
        }

        private int getResult(){

            int[][] dp = new int[N+2][k+2];

            Integer[] diff = new Integer[N];
            int tuzgu=0, ritza = 0;
            //System.out.println("jjjjj");
//            for(int i=0; i<arr.length; i++){
//              //  System.out.print(arr[i] + " ");
//            }
            //System.out.println();
            Arrays.sort(arr, Collections.reverseOrder());
//            for(int i=0; i<arr.length; i++){
//                System.out.print(arr[i] + " ");
//            }
//            System.out.println("-----");

            for(int i=0; i<arr.length; i++){
                if (i%2 == 0){
                    tuzgu += arr[i];
                } else{
                    ritza += arr[i];
                }
                diff[i] = tuzgu-ritza;
            }

            for(int i=1; i<=N; i++){
                dp[i][0] = diff[i-1];
                //System.out.println(dp[i][0] + "xx");

            }

//            for(int i=1; i<=N; i++){
//                for(int j=0; j<=k; j++){
//                    System.out.print(dp[i][j] + " ");
//                }
//                System.out.println();
//            }

            for(int i=2; i<=N; i++){
                for(int j=1; j<Math.min(i, k+1); j++){
                    if ((i-j) % 2 == 0){
                        //System.out.println(arr[i]);
                        dp[i][j] = Math.max(dp[i-1][j-1], dp[i-1][j] - arr[i-1]);
                        //System.out.println(dp[i][j] + " =par ");
                    }else{
                        //System.out.println(i + " "+ j);
                        dp[i][j] = Math.max(dp[i-1][j-1], dp[i-1][j] + arr[i-1]);
                        //System.out.println(dp[i][j] + " =impar ");
                    }
                }
            }

//            for(int i=0; i<=N; i++){
//                for(int j=0; j<=k; j++){
//                    System.out.print(dp[i][j] + " ");
//                }
//                System.out.println();
//            }

            return dp[N][k];
        }

        public void solve(){
            readInput();
            writeOutput(getResult());
        }
    }

    public static void main (String[] args){
        new Task().solve();
    }
}