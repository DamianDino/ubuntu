#include "catch.hpp"

#include "nlohmann/json.hpp"

#include "Replay.hpp"
#include "Generator.hpp"
#include "FractalValueNoiseTileGenerator.hpp"

using namespace hlt;

TEST_CASE("Replay object created and converted to json as expected by visualizer") {
}
