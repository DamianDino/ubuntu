// This file is auto updated by the set_version.sh script.
// The update is run as part of the build process on posix based systems such
// as linux and macOS.

// Define the version of the executable
#define HALITE_VERSION "1.2.2.finals"
